import matplotlib.pyplot as plt
import os.path

# Get the directory name for data files
directory = os.path.dirname(os.path.abspath(__file__))


quantities_harvard = [38, 14, 22, 2, 13, 11]
quantities_ucla = [26, 5, 32, 20, 1, 15]
quantities_princeton = [5, 8, 20, 9, 1, 12]
quantities_calpoly = [20, 1, 24, 39, 0, 12]
quantities_mit = [48, 9, 35, 14, 3, 1]



labels=['White/mixed','African American','Asian','Native American','Hispanic','Other']


colors = ['pink', 'orange', 'green','cyan', 'purple', 'white']


fig, ax = plt.subplots(1, 5)
ax[0].pie(quantities_harvard, labels=labels, colors=colors, autopct='%.0f%%')
ax[0].set_aspect(1) # Square axes for round plot
ax[0].set_title('Harvard')
ax[1].pie(quantities_ucla, labels=labels, colors=colors, autopct='%.0f%%')
ax[1].set_aspect(1) # Square axes for round plot
ax[1].set_title('Ucla')
ax[2].pie(quantities_princeton, labels=labels, colors=colors, autopct='%.0f%%')
ax[2].set_aspect(1) # Square axes for round plot
ax[2].set_title('Princeton')
ax[3].pie(quantities_calpoly, labels=labels, colors=colors, autopct='%.0f%%')
ax[3].set_aspect(1) # Square axes for round plot
ax[3].set_title('Cal Poly')
ax[4].pie(quantities_mit, labels=labels, colors=colors, autopct='%.0f%%')
ax[4].set_aspect(1) # Square axes for round plot
ax[4].set_title('MIT')

fig.show()


#C:\Users\mjgarcia2\Desktop\Data Project